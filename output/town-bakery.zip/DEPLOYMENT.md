# 🎯 Town Bakery - دليل النشر والاستخدام

## ✅ ملخص المشروع

تم بناء موقع Town Bakery بنجاح باستخدام Next.js 14 مع دعم كامل للغة العربية (RTL).

## 📦 الملفات المضافة/المعدلة

### الملفات الجديدة:
- `lib/cart.js` - أدوات إدارة السلة
- `app/(components)/ProductGallery.jsx` - معرض صور المنتجات
- `app/(components)/Toast.jsx` - إشعارات المستخدم
- `scripts/download-assets.js` - تحميل الصور من Unsplash
- `scripts/extract-color.js` - استخراج اللون من الشعار
- `data/contacts.json` - تخزين رسائل الاتصال
- `.env.example` - ملف متغيرات البيئة

### الملفات المحدثة:
- `package.json` - إضافة سكريبتات و Sharp
- `app/api/contact/route.js` - حفظ الرسائل في JSON
- `app/api/orders/route.js` - إضافة PATCH لتحديث حالة الطلب
- `app/api/contacts/route.js` - واجهة برمجية جديدة لعرض الرسائل
- `app/admin/page.jsx` - لوحة تحكم محسنة مع علامات تبويب
- `app/(components)/Navbar.jsx` - استخدام أدوات السلة
- `app/cart/page.jsx` - استخدام أدوات السلة وإشعارات
- `app/products/[slug]/page.jsx` - استخدام ProductGallery و Toast

## 🎨 اللون الأساسي المستخدم (PRIMARY_HEX)

**الحالي**: `#C48A47` (افتراضي)

**لتحديثه**:
1. ضع ملف `logo.png` في `/public/assets/`
2. شغّل: `npm run extract-color`
3. سيتم تحديث `tailwind.config.js` تلقائياً

## 📋 الأوامر للاستخدام المحلي

```bash
# تثبيت المكتبات
npm install

# تحميل الصور (اختياري)
npm run download-assets

# استخراج اللون من الشعار (اختياري)
npm run extract-color

# تشغيل السيرفر المحلي
npm run dev

# بناء المشروع للإنتاج
npm run build

# تشغيل الإنتاج
npm start
```

## 🔐 كلمة مرور الأدمن وكيفية تغييرها

**الافتراضي**: `admin123`

**لتغييرها**:
1. أنشئ ملف `.env.local` من `.env.example`
2. غيّر قيمة `NEXT_PUBLIC_ADMIN_PASSWORD` في `.env.local`
3. أعد تشغيل السيرفر

**ملاحظة**: هذا للنشر التجريبي فقط. للاستخدام الفعلي، استخدم نظام مصادقة مناسب.

## 📸 روابط الصور المستخدمة

تم استخدام Unsplash Source API مع المصطلحات التالية:
- `hero-1.jpg`: "bakery storefront warm interior"
- `product-1.jpg`: "fresh bread loaf"
- `product-2.jpg`: "butter croissant"
- `product-3.jpg`: "chocolate cake"
- `product-4.jpg`: "pancakes honey"
- `product-5.jpg`: "falafel sandwich"
- `product-6.jpg`: "date cookies"
- `chef.jpg`: "baker portrait"

**لتحميل الصور الحقيقية**: شغّل `npm run download-assets`

## 🗄️ تخزين البيانات

**⚠️ للاستخدام التجريبي فقط**: البيانات محفوظة في ملفات JSON:
- `/data/orders.json` - الطلبات
- `/data/contacts.json` - رسائل الاتصال

**للإنتاج**: استبدل بنظام قاعدة بيانات حقيقي (MongoDB, PostgreSQL, إلخ)

## 🚀 النشر على Vercel

1. ادفع الكود إلى GitHub/GitLab
2. استورد المشروع في Vercel
3. أضف متغيرات البيئة:
   - `NEXT_PUBLIC_ADMIN_PASSWORD`
   - `NEXT_PUBLIC_CONTACT_PHONE`
   - `NEXT_PUBLIC_GA_ID` (اختياري)
4. انقر Deploy!

## ✅ التحقق النهائي

- [x] جميع الصفحات تعمل
- [x] إضافة منتج إلى السلة يعمل
- [x] إرسال طلب يعمل
- [x] لوحة الأدمن تعرض الطلبات
- [x] تحديث حالة الطلب يعمل
- [x] نموذج الاتصال يعمل

---

**تم بنجاح! ✅ المشروع جاهز للاستخدام**

